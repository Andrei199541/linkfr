<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	public function index()
	{
		$this->load->view('header');
		$this->load->view('main');
		$this->load->view('footer');
	}

	public function searchCompany() {
		$code = $this->input->get("name");
		$response = array(
			"status" => "403",
			"message" => "Unknown error"
		);
		if (!isset($code)) {
			$response = array(
				"status" => "403",
				"message" => "Please input the correct number."
			);
		} else if (strlen($code) != 9) {
			$response = array(
				"status" => "403",
				"message" => "Siren format error - Expected format: 9 digits."
			);
		} else {
			$this->load->model("main_model");
			$result = $this->main_model->getSirenInfo($code);
			if ($result) {
				$response = array(
					"status" => "200",
					"message" => $result
				);
			}
		}

		exit(json_encode($response));
	}
}
