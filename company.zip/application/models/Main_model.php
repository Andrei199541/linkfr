<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Main_model extends CI_Model {

    public function getSirenInfo($code) {        
        $curr_time = date("Y-m-d H:i");
        $token = $this->getRemainToken($curr_time);
        $authorization = "Authorization: Bearer " . $token;
		$curl = curl_init('https://api.insee.fr/entreprises/sirene/V3/siren/' . $code); 
		curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json' , $authorization ));
		curl_setopt($curl, CURLOPT_FAILONERROR, true); 
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);   
        $result = curl_exec($curl); 
        $result = json_decode($result);
        $statutCode = "";
        if (isset($result->header)) {
            $header = $result->header;
            if (isset($header->statut)) {
                $statutCode = $header->statut;
            }
        }
        if ($statutCode == 200) {
            $legale = $result->uniteLegale;
            $siren = $legale->siren;
            $companyInfo = array();
            if (isset($legale->periodesUniteLegale) && count($legale->periodesUniteLegale)) {
                foreach ($legale->periodesUniteLegale as $periodesUniteLegale) {
                    $siret = "";
                    $denominationUniteLegale = "";
                    $libelleCommuneEtablissement = "";

                    if (!$periodesUniteLegale->dateFin && $periodesUniteLegale->dateDebut) {
                        $siren_end = $periodesUniteLegale->nicSiegeUniteLegale;
                        $siret =  $siren . $siren_end;
                        $denominationUniteLegale = $periodesUniteLegale->denominationUniteLegale;

                        $curl = curl_init('https://api.insee.fr/entreprises/sirene/V3/siret/' . $siret); 
                        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json' , $authorization ));
                        curl_setopt($curl, CURLOPT_FAILONERROR, true); 
                        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
                        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false); 
                        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);   
                        $locationData = curl_exec($curl); 
                        $locationData = json_decode($locationData);
                        if (isset($locationData->etablissement) && isset($locationData->etablissement->adresseEtablissement)) {
                            $adresseEtablissement = $locationData->etablissement->adresseEtablissement;
                            $libelleCommuneEtablissement = $adresseEtablissement->codePostalEtablissement . " " . $adresseEtablissement->libelleCommuneEtablissement;
                            $row = array(
                                "siren" => $siren,
                                "siret" => $siret,
                                "location" => $libelleCommuneEtablissement,
                                "addr" => $denominationUniteLegale
                            );
                            $this->saveResultRow($row, $curr_time, $token);
                            $companyInfo[] = $row;
                        }
                    }
                }
            }
            return $companyInfo;
        } else {
            return false;
        }
    }

    public function getRemainToken($curr_time) {
        $query = 'SELECT * FROM token_info AS a 
        LEFT JOIN ( 
            SELECT *, COUNT(token_key) AS tc FROM result WHERE idate = "' . $curr_time . '" GROUP BY token_key
        ) AS b ON a.token = b.token_key WHERE tc IS NULL OR tc < 30 ORDER BY RAND() LIMIT 1';
        return $this->db->query($query)->row()->token;
    }

    public function saveResultRow($data, $searchTime, $token) {
        $insertAry = array(
            "siren" => $data["siren"],
            "siret" => $data["siret"],
            "location_info" => $data["location"],
            "addr" => $data["addr"],
            "token_key" => $token,
            "idate" => $searchTime
        );
        $this->db->insert("result", $insertAry);
    }
}
?>