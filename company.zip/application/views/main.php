<style>
section {
    padding: 25px;
    border: 4px solid #e3e6e7;
    max-width: 800px;
    margin: 0 auto;
}
.logo {
	background-color: #0288d1;
    color: #fff;
    padding: 20px 50px 20px 20px;
}
.result_row {
	border: 1px solid #e5e5e5;
}
</style>
<div class="row mt-3 logo">
	<div class="col-12 col-xs-12 col-md-12">
		<div class="logo-image">
			<img src="<?php echo base_url("assets/img/logo.png");?>" />
		</div>
	</div>
</div>
<div class="row mt-2">
	<div class="col-12 col-xs-12">
		<section>
			<h3>Please enter the Siren number</h3>
			<div class="input-group input-group-lg mb-3">
				<input type="text" id="company_name" class="form-control" placeholder="SIREN" aria-label="Company (company name or SIREN)">
				<div class="input-group-append">
					<button id="search_button" class="btn btn-outline-primary fa fa-search" type="button"> Search</button>
				</div>
			</div>
		</section>
	</div>
</div>
<div id="result">
	
</div>
<script type="text/javascript">
function searchCompany() {
	var company_name = $("#company_name").val();
	if (!company_name) return;
	$.ajax({
		url: site_url + "main/searchCompany",
		type: "GET",
		dataType: "JSON",
		data: {name: company_name},
		success: function(res) {
			if (res.status == 200) {
				var searchResult = "";
				searchResult += '<div class="row mt-3 result_row" v-for="row in searchResult">\
									<div class="col-4 p-3 text-center">\
										<span>{{row.addr}}</span>\
									</div>\
									<div class="col-4 p-3 text-center">\
										<span>{{row.location}}</span>\
									</div>\
									<div class="col-4 p-3 text-center">\
										<span>{{row.siret}}</span>\
									</div>\
								</div>\
				';
				$("#result").html(searchResult);
				var app6 = new Vue({
					el: '#result',
					data: {
						searchResult: res.message
					}
				})
			} else {
				alert(res.message);
			}
		}
	});
}
$("#company_name").on("keyup", function(e) {
	var code = e.which;
    if(code==13) {
		searchCompany();
	}    
});
$("#search_button").on("click", searchCompany);
</script>
<script src="https://unpkg.com/vue/dist/vue.js"></script>